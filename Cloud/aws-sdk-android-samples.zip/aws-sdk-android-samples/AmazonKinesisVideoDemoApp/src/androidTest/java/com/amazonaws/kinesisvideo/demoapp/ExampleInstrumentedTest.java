package com.amazonaws.kinesisvideo.demoapp;

import android.content.Context;

import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertEquals;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleInstrumentedTest {

    /**
     * Instrumented test example.
     */
    @Test
    public void useAppContext() {
        // Context of the app under test.
    }
}
