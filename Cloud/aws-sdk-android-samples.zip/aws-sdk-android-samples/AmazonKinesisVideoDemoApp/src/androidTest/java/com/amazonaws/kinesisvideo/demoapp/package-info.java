/**
 * Instrumented tests go here.
 */
package com.amazonaws.kinesisvideo.demoapp;
